package com.ProjectExhibition;
import javax.swing.*;
class NewPage extends JFrame
{
    NewPage()
    {
        setDefaultCloseOperation(javax.swing.
                WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Captcha Successfully Verfied");
        setSize(400, 200);
    }
}
